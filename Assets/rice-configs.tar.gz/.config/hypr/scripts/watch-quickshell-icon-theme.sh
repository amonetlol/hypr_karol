#!/usr/bin/env bash
set -euo pipefail
config="${1:-karol}"
while true; do
    gsettings monitor org.gnome.desktop.interface icon-theme | while IFS= read -r _; do
        "$HOME/.config/hypr/scripts/quickshell-reload.sh" "$config" --restart
    done || true
    sleep 1
done
