#!/usr/bin/env bash
set -euo pipefail
systemctl --user import-environment WAYLAND_DISPLAY XDG_RUNTIME_DIR HYPRLAND_INSTANCE_SIGNATURE XDG_CURRENT_DESKTOP
pkill -x hyprpaper >/dev/null 2>&1 || true
if ! pgrep -x awww-daemon >/dev/null 2>&1; then
    setsid awww-daemon >/dev/null 2>&1 < /dev/null &
fi
image=""
if [ -r "$HOME/.cache/current-wallpaper" ]; then
    IFS= read -r image < "$HOME/.cache/current-wallpaper" || true
fi
if [ ! -f "$image" ]; then
    image="$HOME/Imagens/wallpapers/wallpaper2.jpg"
fi
for attempt in {1..30}; do
    if awww query >/dev/null 2>&1; then
        if [ -f "$image" ]; then
            awww img "$image" --transition-type grow --transition-pos 0.5,0.5 --transition-duration 1 --transition-fps 60
        fi
        break
    fi
    sleep 0.1
done
systemctl --user restart elephant.service
sleep 1
"$HOME/.config/hypr/scripts/quickshell-reload.sh" karol
systemctl --user start quickshell-icon-theme.service
