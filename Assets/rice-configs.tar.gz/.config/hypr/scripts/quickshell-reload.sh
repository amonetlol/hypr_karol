#!/usr/bin/env bash
set -euo pipefail
export QT_QUICK_BACKEND="${QT_QUICK_BACKEND:-software}"
export GDK_BACKEND="${GDK_BACKEND:-wayland,x11,*}"
if [ -z "$(printenv XDG_CONFIG_HOME)" ]; then unset XDG_CONFIG_HOME; fi
if [ -z "${XDG_CONFIG_HOME:-}" ]; then unset XDG_CONFIG_HOME; fi
config="${1:-karol}"
force_restart="${2:-}"
config_path="$HOME/.config/quickshell/$config"
state="${XDG_RUNTIME_DIR:-/tmp}/quickshell"
icon_theme="$(gsettings get org.gnome.desktop.interface icon-theme 2>/dev/null | sed -e "s/^'//" -e "s/'$//" || true)"
if [ -n "$icon_theme" ]; then
    export QS_ICON_THEME="$icon_theme"
else
    unset QS_ICON_THEME
fi
prune() {
	local link pid target
	[ -d "${state}/by-pid" ] || return 0
	for link in "${state}"/by-pid/*; do
		[ -L "$link" ] || continue
		pid="${link##*/}"
		kill -0 "$pid" 2>/dev/null && continue
		target="$(readlink -f "$link" 2>/dev/null || true)"
		case "$target" in "${state}"/by-id/*) rm -rf "$target" ;; esac
		rm -f "$link"
	done
	for link in "${state}"/by-shell/*/* "${state}"/by-path/*; do
		[ -L "$link" ] || continue
		[ -e "$link" ] || rm -f "$link"
	done
}
current_theme=""
qs_pid="$(pgrep -x qs | head -n 1 || true)"
if [ -n "$qs_pid" ] && [ -r "/proc/$qs_pid/environ" ]; then
    current_theme="$(tr '\0' '\n' < "/proc/$qs_pid/environ" | sed -n 's/^QS_ICON_THEME=//p' | head -n 1 || true)"
fi
if [ "$force_restart" != "--restart" ] && [ "$current_theme" = "${QS_ICON_THEME:-}" ]; then
    if timeout 3 qs -p "$config_path" ipc call shell reload >/dev/null 2>&1; then exit 0; fi
fi
prune
pkill -x qs >/dev/null 2>&1 || true
sleep 0.2
setsid qs -p "$config_path" -d >/dev/null 2>&1 < /dev/null &
