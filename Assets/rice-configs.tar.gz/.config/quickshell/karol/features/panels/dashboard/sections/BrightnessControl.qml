import QtQuick
import qs.services
import qs.widgets.containers

LevelRow {
    enabled: Brightness.available
    opacity: Brightness.available ? 1.0 : 0.55
    icon: Brightness.icon
    iconState: Brightness.available ? "default" : "disabled"
    value: Brightness.available ? Brightness.brightness : 0
    onMoved: value => Brightness.setBrightness(value)
}
