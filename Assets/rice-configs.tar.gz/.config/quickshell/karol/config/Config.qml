pragma Singleton

import QtQuick
import Quickshell

Singleton {
    id: root

    readonly property var pinnedApps: [
        { name: "Firefox", appId: "firefox", exec: "firefox" },
        { name: "Foot", appId: "foot", exec: "foot" },
        { name: "Thunar", appId: "org.xfce.thunar", exec: "thunar" }
    ]

    readonly property bool showFrame: true
    readonly property int maxWorkspaces: 10
}
