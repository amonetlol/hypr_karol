import QtQuick
import QtQuick.Effects
import qs.theme

Item {
    id: root

    property string name: ""
    property int size: Spacing.iconMd
    property string iconState: "default"
    readonly property string nerdGlyph: {
        switch (root.name) {
            case "house": return "\uf015"
            case "bell": return "\uf0f3"
            case "bell-slash": return "\uf1f6"
            case "magnifying-glass": return "\uf002"
            case "sliders-horizontal": return "\uf1de"
            case "gear": return "\uf013"
            case "wifi-high":
            case "wifi-medium":
            case "wifi-low":
            case "wifi-slash":
            case "wifi-none":
            case "wifi-x": return "\uf1eb"
            case "speaker-high": return "\uf028"
            case "speaker-low": return "\uf027"
            case "speaker-none":
            case "speaker-slash":
            case "speaker-x": return "\uf026"
            case "lock-simple": return "\uf023"
            case "sign-out": return "\uf08b"
            case "moon": return "\uf186"
            case "arrow-counter-clockwise": return "\uf0e2"
            case "power": return "\uf011"
            default: return ""
        }
    }

    Text {
        anchors.fill: parent
        visible: root.nerdGlyph !== ""
        text: root.nerdGlyph
        font.family: Typography.monoFamily
        font.pixelSize: Math.round(root.size * 0.9)
        color: root.color
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
        renderType: Text.NativeRendering
    }


    property color color: {
        switch (iconState) {
            case "hover": return Colors.iconHoverPrimary
            case "active": return Colors.iconActivePrimary
            case "disabled": return Colors.iconDisabledPrimary
            default: return Colors.iconPrimary
        }
    }

    implicitWidth: size
    implicitHeight: size
    width: size
    height: size

    Image {
        id: iconImage
        anchors.fill: parent
        sourceSize.width: root.size * 2
        sourceSize.height: root.size * 2
        fillMode: Image.PreserveAspectFit
        smooth: true
        antialiasing: true
        asynchronous: false
        visible: false

        source: {
            if (root.name === "") {
                return ""
            }
            const basePath = Qt.resolvedUrl("../../assets/phosphor-icons/duotone")
            return basePath + "/" + root.name + "-duotone.svg"
        }
    }

    MultiEffect {
        anchors.fill: parent
        source: iconImage
        brightness: 1.0
        colorization: 1.0
        colorizationColor: root.color
        visible: iconImage.status === Image.Ready && root.nerdGlyph === ""
    }

    Image {
        id: fallbackImage
        anchors.fill: parent
        sourceSize.width: root.size * 2
        sourceSize.height: root.size * 2
        fillMode: Image.PreserveAspectFit
        smooth: true
        antialiasing: true
        asynchronous: false
        visible: false

        source: {
            if (root.name === "") {
                return ""
            }
            const basePath = Qt.resolvedUrl("../../assets/phosphor-icons/regular")
            return basePath + "/" + root.name + ".svg"
        }
    }

    MultiEffect {
        anchors.fill: parent
        source: fallbackImage
        brightness: 1.0
        colorization: 1.0
        colorizationColor: root.color
        visible: root.nerdGlyph === "" && iconImage.status !== Image.Ready && fallbackImage.status === Image.Ready
    }

    Rectangle {
        anchors.centerIn: parent
        width: root.size * 0.7
        height: root.size * 0.7
        radius: Spacing.radiusNested
        color: "transparent"
        border.width: 1
        border.color: Colors.textDim
        visible: root.nerdGlyph === "" && iconImage.status !== Image.Ready && fallbackImage.status !== Image.Ready

        Text {
            anchors.centerIn: parent
            text: "?"
            font.pixelSize: root.size * 0.4
            font.family: Typography.bodyFamily
            color: Colors.textDim
        }
    }

    Behavior on color {
        ColorAnimation { duration: Motion.hoverDuration }
    }
}
